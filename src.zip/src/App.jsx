import React from 'react'
import Button from './components/Button'
import Navbar from './components/Navbar'
import Hero from './pages/Hero'
import Footer from './components/Footer'
import BestSelling from './pages/BestSelling'
import AboutUs from './pages/AboutUs'


function App() {
  return (
    <div>
      
        <Navbar />
        <Hero />

        <Footer />
        <BestSelling />
        <AboutUs />
        
        
      
      
    </div>
  )
}

export default App

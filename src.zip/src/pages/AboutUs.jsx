import React from 'react';
import MissionImage from '../assets/facebook.png';
import StoryImage from '../assets/facebook.png';
import ApproachImage from '../assets/facebook.png';

const AboutUs = () => {
  return (
    <div className="container mx-auto py-16">
      <h2 className="text-2xl font-bold text-center mb-8">About Us</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
        <div className="flex flex-col sm:flex-row items-center">
          <div className="sm:w-1/2">
            <h3 className="text-lg font-bold mb-4">Our Mission</h3>
            <p className="text-gray-600 mb-4">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean efficitur, lectus at pulvinar pulvinar, leo metus feugiat arcu, id dignissim lectus leo eget eros. Nunc auctor rutrum magna vitae auctor.
            </p>
          </div>
          <div className="sm:w-1/2">
            <img src={MissionImage} alt="Mission" className="mx-auto w-64 h-64" />
          </div>
        </div>
        <div className="flex flex-col sm:flex-row items-center">
         
          <div className="sm:w-1/2">
            <h3 className="text-lg font-bold mb-4">Our Short Story</h3>
            <p className="text-gray-600 mb-4">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean efficitur, lectus at pulvinar pulvinar, leo metus feugiat arcu, id dignissim lectus leo eget eros. Nunc auctor rutrum magna vitae auctor.
            </p>
          </div>
          <div className="sm:w-1/2">
            <img src={StoryImage} alt="Story" className="mx-auto w-64 h-64" />
          </div>
        </div>
        <div className="flex flex-col sm:flex-row items-center">
          <div className="sm:w-1/2">
            <h3 className="text-lg font-bold mb-4">Our Approach</h3>
            <p className="text-gray-600 mb-4">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean efficitur, lectus at pulvinar pulvinar, leo metus feugiat arcu, id dignissim lectus leo eget eros. Nunc auctor rutrum magna vitae auctor.
            </p>
          </div>
          <div className="sm:w-1/2">
            <img src={ApproachImage} alt="Approach" className="mx-auto w-64 h-64" />
          </div>
        </div>
        
      </div>
    </div>
  );
};

export default AboutUs;

import React from 'react';
import Product1 from '../assets/vercel.png';
import Product2 from '../assets/vercel.png';
import Product3 from '../assets/facebook.png';

const BestSelling = () => {
    return (
      <div className="container mx-auto py-16">
        <h2 className="text-2xl font-bold text-center mb-8">Best Selling</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          <div className="bg-white rounded-md shadow-md p-4">
            <img src={Product1} alt="Product 1" className="mx-auto mb-4 w-32 h-32" />
            <h3 className="text-lg font-bold mb-2">Product 1</h3>
            <p className="text-gray-600 mb-4">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
            <div className="flex justify-between">
              <p className="text-lg font-bold">$19.99</p>
              <div>
                <button className="bg-gray-200 text-gray-800 px-3 py-2 rounded-full mr-2">Add to Cart</button>
                <button className="bg-red-500 text-white px-3 py-2 rounded-full">Buy Now</button>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-md shadow-md p-4">
            <img src={Product2} alt="Product 2" className="mx-auto mb-4 w-32 h-32" />
            <h3 className="text-lg font-bold mb-2">Product 2</h3>
            <p className="text-gray-600 mb-4">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
            <div className="flex justify-between">
              <p className="text-lg font-bold">$24.99</p>
              <div>
                <button className="bg-gray-200 text-gray-800 px-3 py-2 rounded-full mr-2">Add to Cart</button>
                <button className="bg-red-500 text-white px-3 py-2 rounded-full">Buy Now</button>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-md shadow-md p-4">
            <img src={Product3} alt="Product 3" className="mx-auto mb-4 w-32 h-32" />
            <h3 className="text-lg font-bold mb-2">Product 3</h3>
            <p className="text-gray-600 mb-4">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
            <div className="flex justify-between">
              <p className="text-lg font-bold">$29.99</p>
              <div>
                <button className="bg-gray-200 text-gray-800 px-3 py-2 rounded-full mr-2">Add to Cart</button>
                <button className="bg-red-500 text-white px-3 py-2 rounded-full">Buy Now</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };
  
  export default BestSelling;
  

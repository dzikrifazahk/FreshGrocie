import React from 'react';
import Figma from '../assets/figma.png';
import Facebook from '../assets/facebook.png';
import Vercel from '../assets/vercel.png';
import Cardhero from '../components/Cardhero';
import Ilustration1 from '../assets/Illustration_1.png';

const Hero = () => {
  return (
    <div className="flex flex-col items-center my-20 font-poppins lg:my-[150px]">
      <div className="container max-w-5xl mx-auto grid grid-cols-1 lg:grid-cols-2 py-24">
        <div className="pb-24 lg:pb-0 lg:pr-24">
          <h1 className="font-bold text-4xl pt-24 text-center lg:text-left">
            Want anything to be easy
            <br />
            with LaslesVPN.
          </h1>
          <div className="font-normal text-xs pb-12 text-center lg:text-left">
            Provide a network for all your needs with ease and fun using LaslesVPN. Discover interesting features from us.
          </div>
          <div className="flex justify-center lg:justify-start"> 
            <button className="py-4 px-16 bg-red-500 rounded-md text-white drop-shadow-3xl">
              Get Started
            </button>
          </div>
        </div>
        <div className="flex justify-center">
          <img src={Ilustration1} alt="ilustration-laslesvpn" className="max-w-full h-auto" />
        </div>
      </div>
      <div className="flex flex-col gap-6">
        <h1 className="font-semibold text-slate-600 text-center">Featured Jobs</h1>
        <div className="flex flex-col gap-4 lg:flex-row">
          <Cardhero
            imgUrl={Figma}
            jobTitle="Front-end Developer"
            platform="Figma"
            text="We are looking for an experienced front-end developer to join our team."
            tag="Rust"
            currency="$70,000 - $90,000"
          />
          <Cardhero
            imgUrl={Facebook}
            jobTitle="Data Scientist"
            platform="Facebook"
            text="We are seeking a data scientist to join our team."
            tag="Python"
            currency="$100,000 - $130,000"
          />
          <Cardhero
            imgUrl={Vercel}
            jobTitle="Technical Writer"
            platform="Vercel"
            text="We are seeking a technical writer to join our team."
            tag="Documentation"
            currency="$60,000 - $80,000"
          />
        </div>
      </div>
    </div>
  );
};

export default Hero;
